import org.apache.spark.sql.SparkSession
import java.util.Properties

object ScalaPgData {

  def main(args: Array[String]): Unit = {
    println("Hello Spark Scala")

    System.setProperty("hadoop.home.dir","C:\\winutils")
    
	
    //Create a Spark Session
    println("Starting SparkSession")
    val spark = SparkSession
      .builder()
      .config("spark.master", "local")
      //.config("spark.driver.memory", "800000000")
      //.config("spark.executor.memory", "400000000")
      .appName("HelloSpark")
      .enableHiveSupport()
      .getOrCreate()
	  //println(spark.conf)
    println("Created Spark Session...")
	
	
	
    //val sampleSeq = Seq((1,"spark"),(2,"Big Data"))
    //val df = spark.createDataFrame(sampleSeq).toDF("course id", "course name")
   // df.show()
   // df.write.format(source="csv").save(path="samplesq")
	
	
	
    //winutils.exe chmod -R 777 \tmp\hive
    //Create Dataframe from PG table Coursetable
	// Reading the Data from Postgres
    val pgConnectionProperties = new Properties()
    pgConnectionProperties.put("user","postgres")
    pgConnectionProperties.put("password","hero1975")

    val pgTable = "futureschema.futurex_course_catalog"
    val pgCourseDataframe = spark.read.jdbc("jdbc:postgresql://localhost:5432/futurex",pgTable,pgConnectionProperties)
    
	pgCourseDataframe.show()

  }


}
